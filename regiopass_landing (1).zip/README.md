# RegioPass - Landing Page

🌐 Sitio web informativo de la aplicación **RegioPass**, una solución inteligente para la validación de pasajes en el sistema Regiotram de Occidente mediante tecnología NFC y QR.

## 🚀 ¿Qué es RegioPass?

RegioPass es una app móvil que permite a los usuarios validar su ingreso al Regiotram de manera digital, segura y sin contacto, a través de sus dispositivos móviles.

## 🧩 Características del sitio

- Página de destino informativa y responsiva
- Secciones:
  - ¿Cómo funciona?
  - Recargas y tarifas
  - App móvil
  - Contacto
- Diseño limpio con Tailwind CSS

## 📂 Estructura

/regiopass-landing
│
├── index.html     # Archivo principal del sitio web
├── README.md      # Descripción del proyecto

## 🌍 Despliegue

Esta página está optimizada para ser desplegada en **Vercel**, con soporte automático para HTTPS y conexión a dominio personalizado.

### Enlace temporal de prueba (Vercel):
👉 `https://regiopass-landing.vercel.app` *(ejemplo, cambia cuando se publique)*

## 📧 Contacto

- Correo: contacto@regiopass.co
- Proyecto creado por: Juan Carlos Mendivelso Portilla
